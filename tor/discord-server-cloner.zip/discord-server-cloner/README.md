# Discord Server Cloner
An efficient tool to clone Discord server without having any need of admin privileges.

## Features
- **No Admin Privileges Needed**: Clone servers without requiring admin rights.
- **Full Server Replication**: Copy channels, roles, categories, and other server settings.
- **User-Friendly**: Simple interface and easy to follow prompts.
- **Customizable Cloning**: Choose whether to include server emojis in the clone.

## Screenshots
![Screenshot 1](https://media.discordapp.net/attachments/1281652598046462078/1283058516294373467/chrome_fTgRUXKW3c.png?ex=66e19cdc&is=66e04b5c&hm=de75be5b04ccf76df5a6c2b1418cdb078c4097795cd6f232c75753dd01e5baad&=&format=webp&quality=lossless)

![Screenshot 2](https://media.discordapp.net/attachments/1281652598046462078/1283058459277004800/image.png?ex=66e19cce&is=66e04b4e&hm=312328f4d7be371f17202885c4b7cb3f67bca3a4543b5d7178fe346080a3e3ff&=&format=webp&quality=lossless&width=1184&height=676)


## Installation & Usage
1. Download the repository and extract the files.
2. Run the `install.bat` file to install all necessary Python packages.
3. Follow the on-screen instructions to provide your Discord token and server IDs.
4. The tool will guide you through the cloning process.
